package com.joct.SpringBootProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
