package com.first.exceptions;

public class StudentIdNotFoundException extends Exception{
    public StudentIdNotFoundException(String mesg){
        super(mesg);

    }
}
