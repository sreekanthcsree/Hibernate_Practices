# SpringBoot-Application once clone this application try to build it first and then hit the swagger UI url to find out the API's.
Swagger URl -http://localhost:8080/v2/api-docs
Swagger UI url -http://localhost:8080/swagger-ui.html
