package com.joct.SpringBootCRUDEx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootCrudExApplicationTests {

	@Test
	void contextLoads() {
	}

}
